# CoronaCounter
Have you ever wanted a covid-19 counter programmed in rust? No? Well I did, and so I created it.

`cargo run`